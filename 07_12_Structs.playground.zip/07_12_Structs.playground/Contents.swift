import UIKit

class PizzaClass{
    var size:Int
    var topping:String
    init(size:Int,topping:String){
        self.size = size
        self.topping = topping
    }
    func printPizza(){
        print("\(size) inch Pizza with \(topping)")
    }
}

struct PizzaStruct{
    var size:Int
    var topping:String
    init(size:Int,topping:String){
        self.size = size
        self.topping = topping
    }
    func printPizza(){
        print("\(size) inch Pizza with \(topping)")
    }
}

let pizzaStruct = PizzaStruct(size: 10, topping: "Pepperoni")
let pizzaClass = PizzaClass(size: 10, topping: "BBQ Chicken")

